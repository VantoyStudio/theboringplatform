<?php
/**
 * Featured badge template
 */

echo $this->__get_badge_image();
